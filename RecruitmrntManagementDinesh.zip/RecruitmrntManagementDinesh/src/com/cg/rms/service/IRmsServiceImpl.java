package com.cg.rms.service;

import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.dao.IRmsDao;
import com.cg.rms.dao.IRmsDaoImpl;
import com.cg.rms.exception.RecruitmentManagementException;

public class IRmsServiceImpl implements IRmsService {

	IRmsDao rdao=new IRmsDaoImpl();	
	
	@Override
	public String insertCandidateWorkHistory(CandidateWorkHistory chistory)
			throws RecruitmentManagementException {
		// TODO Auto-generated method stub
		return rdao.insertCandidateWorkHistory(chistory);
	}

}

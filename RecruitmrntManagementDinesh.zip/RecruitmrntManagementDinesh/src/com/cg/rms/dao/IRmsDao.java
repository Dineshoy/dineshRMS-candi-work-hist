package com.cg.rms.dao;

import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;

public interface IRmsDao {
	
	String insertCandidateWorkHistory(CandidateWorkHistory chistory) throws RecruitmentManagementException;


}

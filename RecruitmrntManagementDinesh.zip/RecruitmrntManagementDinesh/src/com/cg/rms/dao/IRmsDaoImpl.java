package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.exception.RecruitmentManagementException;

public class IRmsDaoImpl implements IRmsDao {
	
	private Connection conn;
	
	

	private String generateWorkId() throws RecruitmentManagementException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_work_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			throw new RecruitmentManagementException("problem in generating course Id"+e.getMessage());
		}
	}
	
	
	@Override
	public String insertCandidateWorkHistory(CandidateWorkHistory chistory) throws RecruitmentManagementException {
		
		
		chistory.setWork_id(generateWorkId());
		String sql ="INSERT INTO candidate_work_history VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1, chistory.getWork_id());
		pst.setString(2, chistory.getCandidate_id());
		pst.setString(3, chistory.getWhich_employer());
		pst.setString(4, chistory.getContact_person());
		pst.setString(5, chistory.getPosition_held());
		pst.setString(6, chistory.getCompany_name());
		pst.setString(7, chistory.getEmployement_from());
		pst.setString(8, chistory.getEmployement_to());
		pst.setString(9, chistory.getReason_for_leaving());
		pst.setString(10, chistory.getResponsibilities());
		pst.setString(11, chistory.getHr_rep_name());
		pst.setString(12, chistory.getHr_rep_contact_num());
		
		pst.executeUpdate();
		//logger.info("Registration completed successfully for"+cmaster);
		
	}catch (SQLException e) {
		throw new RecruitmentManagementException("problem in inserting"
				+"work history details"+e.getMessage());
	}
		return chistory.getWork_id();
	}


	
	
	
	
	
	
	
	
	}
	
